<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>ZONAfilm</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>

  <body>

    <nav class="navbar navbar-default navbar-fixed-top" style="background:#F9966B;">
      <div class="container-fluid">
        <div class="navbar-header">
          
          <a class="navbar-brand" href="#" style="color:#fff; font-size:30px;">ZONA<b>film</b></a>
        </div>
        <div class="collapse navbar-collapse">


        <div class="nav navbar-nav navbar-right">
         <ul id="nav">
          <li ><a href="index.php" style="color:#fff;"><span class="glyphicon glyphicon-home"> Home | </span></a></li>
          <li><a href="" style="color:#fff;" ><span class="glyphicon glyphicon-list"> Kategori | </span></a>
<ul>
<li><?php include("kat.php");?></li>

</ul>
</li>
          <li class="a"><a href="login.php" style="color:#fff;"><span class="glyphicon glyphicon-log-in"> Login | </span></a></li>
          </ul>
          <div class="clear"></div>
          
          </div>
      </div>
    </nav>
    <div class="jumbotron">
      <div class="row">
      <div class="col-md-4" style="margin:30px;">
     <img src="img/1.jpg">   
    </div>
      <div class="col-md-6" style="margin-left:70px;">
         <h2><b>Selamat datang di<h1 style="color:#f97b61;">ZONA<b>film</b></h1></h2>
        <p>website yang tepat untuk memperoleh informasi tentang film terbaru favorit anda</p>
      </div>
    </div>
    </div>
<div style="margin-top: -30px; width:100%,height:50px;text-align:center;background:#F9966B;color:#fff;line-height:60px;font-size:20px;">
<b>Daftar Film</b>
</div>
    <div class="container">
      <div class="row">
      <?php
      @$idkat = $_GET['id'] ;
      $qryfilmkat = mysql_query("SELECT * from film where id_ketegori='$idkat'");
      $qryfilm= mysql_query("SELECT * from film");
      if($idkat==0){
      while($film = mysql_fetch_array($qryfilm)) {
      ?>
      
        <div class="col-md-4" style="margin-top:20px;">
        <div class="film">
        <center><img src="gambar/<?php echo $film['gambar'] ?>" style="margin-top:20px; width:200px;height:190px;"></center>
         <h3 style="text-align:center; color:#0000ff;"><?php echo $film['judul'] ?></h3>
          <center><b>Produksi</b><?php echo $film['produksi']; ?></center> 
          <center><b>Tahun</b> (<?php echo $film['tahun']; ?>)</center>
          <center><a class="btn btn-danger" href="detail.php?id=<?php echo $film['id_film'] ?>" role="button" style="margin-top:10px;">Jadwal Bioskop &raquo;</a></center>
         </div>
        </div>
        <?php } }
        else{ while($film1 = mysql_fetch_array($qryfilmkat)){?>
            <div class="col-md-4" style="margin-top:20px;">
        <div class="film">
        <center><img src="gambar/<?php echo $film1['gambar'] ?>" style="margin-top:20px;width:200px;height:190px;"></center>
        <h3 style="text-align:center; color:#0000ff; "><?php echo $film1['judul'] ?></h3>
          <center><b>Produksi</b><?php echo $film1['produksi']; ?></center> 
          <center><b>Tahun</b> (<?php echo $buku1['tahun']; ?>)</center>
          <center><a class="btn btn-danger" href="detail.php?id=<?php echo $film1['id_film'] ?>" role="button" style="margin-top:10px;">Jadwal Bioskop &raquo;</a></center>
         </div>
        </div>
          <?php }} ?>
      </div>

      <hr>

      
    </div> 
     
      <div class="footer" style="width:100%;height:270px;color:#fff;background:#F9966B;">
      <div class="row" style="background:#7e7c78;">
      <div class="col-md-4">
      <div style="margin:50px;height:120px;">
        <center>
        <ul>
          <li style="color:#f97b61"><h3><b>Tentang ZONAfilm</b></h3></li>
        </ul></center>
          <hr>
        <ul>
          <li><b>ZONAfilm</b> adalah</li>
          <li>Website yang menyediakan</li>
          <li>informasi mengenai film terbaru</li>
          <li>untuk penikmat film</li>
          <li>berdasarkan kategori.</li>
        </ul>
      </div>
      </div>
      <div class="col-md-4">
      <div style="margin:50px;height:120px;">
        <center>
        <ul>
          <li style="color:#f97b61"><h3><b>Contact Us</b></h3></li>
          <hr>
         <div class="row">
          <div class="col-md-4">
          <a href=""><img src="images/fb.png" style="width:70px;height:75px;  "></a>
          </div>
          <div class="col-md-4">
          <a href=""><img src="images/gp.png" style="width:70px;height:75px;"></a>
          </div>
          <div class="col-md-4">
          <a href=""><img src="images/Twitter.png" style="width:70px;height:75px;"></a>
          </div>
         </div>
        </ul>
        </center>
      </div>
      </div>
      </div>
        <div class="copyright" style="line-height:50px;">
        <center>&copy; 2018 Nur Widiyati P.</center>
        </div>
      </div>
  </body>
</html>