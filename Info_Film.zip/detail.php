<?php
include"config.php";
$id = $_GET['id'];
$qry = mysql_query("SELECT * from film where id_film='$id'");
$data = mysql_fetch_array($qry);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>ZONAfilm</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>

  <body>

    <nav class="navbar navbar-default navbar-fixed-top" style="background:#F9966B;">
      <div class="container-fluid">
        <div class="navbar-header">
          
         <a class="navbar-brand" href="#" style="color:#fff; font-size:30px;">ZONA<b>film</b></a>
        </div>
        <div class="collapse navbar-collapse">


        <div class="nav navbar-nav navbar-right">
         <ul id="nav">
          <li ><a href="index.php" style="color:#fff;"><span class="glyphicon glyphicon-home"> Home | </span></a></li>
          <li><a href="" style="color:#fff;" ><span class="glyphicon glyphicon-list"> Kategori | </span></a>
<ul>
<li><?php include("kat.php");?></li>

</ul>
</li>
          <li class="a"><a href="login.php" style="color:#fff;"><span class="glyphicon glyphicon-log-in"> Login</span></a></li>
          </ul>
          <div class="clear"></div>
          
          </div>
      </div>
    </nav>
    <div class="jumbotron">
      <div class="row">
      <div class="col-md-3" style="margin:30px;">
     <img src="gambar/<?php echo $data['gambar']; ?>" style="width:250px; height:250px;">   
    </div>
      <div class="col-md-6" style="margin-left:10px ; margin-top:10px;">
        	<table border="1">
    <tr>
        <th>Bioskop</th> 
        <th>Jadwal Film</th> 
        <th>Harga Tiket</th> 
    </tr>
    <tr>
		</td> <td><?php echo $data['bioskop']; ?></td>
        <td><?php echo $data['jadwal']; ?></td>
        <td><?php echo $data['tiket']; ?></td>
    </tr>
	</table>
        </div>
    </div>
    </div>

    <div style="margin-top: -30px; width:100%,height:50px;text-align:center;background:#d74b35;color:#fff;line-height:60px;font-size:20px;">
<b>Daftar Film</b>
</div>
<div class="container">
      <div class="row">
      <?php
      $qryfilm= mysql_query("SELECT * from film");
      while($film = mysql_fetch_array($qryfilm)) {
      ?>

      <div class="col-md-3" style="margin-top:20px;">
        <div class="film">
        <center><img src="gambar/<?php echo $film['gambar'] ?>" style="margin-top:20px; width:210px;height:190px;"></center>
         <h3 style="text-align:center; color:#f97b61;"><?php echo $film['judul'] ?></h3>
          <center><b>Produksi</b><?php echo $film['produksi']; ?></center> 
          <center><b>Tahun</b> (<?php echo $film['tahun']; ?>)</center>
          <center><a class="btn btn-danger" href="detail.php?id=<?php echo $film['id_film'] ?>" role="button" style="margin-top:10px;">Jadwal Bioskop &raquo;</a></center>
         </div>
        </div>

        <?php } ?>
      </div>

      <hr>

      
    </div> 
   <div class="footer" style="width:100%;height:270px;color:#fff;background:#F9966B;">
      <div class="row" style="background:#7e7c78;">
      <div class="col-md-4">
      <div style="margin:50px;height:120px;">
        <center>
        <ul>
          <li style="color:#f97b61"><h3><b>Tentang ZONAfilm</b></h3></li>
        </ul></center>
          <hr>
        <ul>
          <li><b>ZONAfilm</b> adalah</li>
          <li>Website yang menyediakan</li>
          <li>informasi mengenai film terbaru</li>
          <li>untuk penikmat film</li>
          <li>berdasarkan kategori.</li>
        </ul>
      </div>
      </div>
      <div class="col-md-4">
      <div style="margin:50px;height:120px;">
        <center>
         <ul>
          <li style="color:#f97b61"><h3><b>Contact Us</b></h3></li>
          <hr>
         <div class="row">
          <div class="col-md-4">
          <a href="www.fecebook.com"><img src="images/fb.png" style="width:70px;height:75px;  "></a>
          </div>
          <div class="col-md-4">
          <a href="www.googleplus.com"><img src="images/gp.png" style="width:70px;height:75px;"></a>
          </div>
          <div class="col-md-4">
          <a href=""><img src="images/Twitter.png" style="width:70px;height:75px;"></a>
          </div>
         </div>
        </ul>
        </center>
      </div>
      </div>
      </div>
        <div class="copyright" style="line-height:50px;">
        <center>&copy; 2018 Nur Widiyati P.</center>
        </div>
      </div>
  </body>
</html>