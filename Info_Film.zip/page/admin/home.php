<div class="jumbotron" style="margin-top:30px">
      <div class="row">
      <div class="col-md-5">
     <img src="../../img/1.jpg" style="width:400px;height:300px;">   
    </div>
      <div class="col-md-6" style="margin-top: 50px;margin-left: 60px;">
        <h3><b>Selamat datang di Halaman ADMIN</b></h3>
        <p>Disini anda bisa memanegeman dari data <b>Kategori</b>, <b>Film</b></p>
      </div>
    </div>
    </div>