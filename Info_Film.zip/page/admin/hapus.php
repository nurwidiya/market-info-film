<?php
include('../../config.php');
$bk=$_GET['id'];
mysql_query("DELETE FROM film WHERE id_film='$bk'");
header("location:index.php?page=film");
 ?>