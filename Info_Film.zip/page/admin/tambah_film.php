<?php
include"../../config.php";
	$kat = $_POST['kat'];
	$judul = $_POST['judul'];
	$produksi = $_POST['produksi'];
	$tahun = $_POST['tahun'];
	$bioskop = $_POST['bioskop'];
	$jadwal = $_POST['jadwal'];
	$tiket = $_POST['tiket'];
	$qryid = mysql_query("SELECT * FROM kategori where kategori='$kat'");
	$data = mysql_fetch_array($qryid);
	$id_kategori = $data['id_ketegori'];

@$message		= '';
$valid_file		= true;
$max_size		= 1024000; 


if($_FILES['gambar']['name']){
	
	if(!$_FILES['gambar']['error']){

		
		$new_file_name = strtolower($_FILES['gambar']['tmp_name']); 
		if($_FILES['gambar']['size'] > $max_size) 
		{
			$valid_file	= false;
			$message	= 'Maaf, file terlalu besar. Max: 1MB';
		}
	


		
		$image_path = pathinfo($_FILES['gambar']['name'],PATHINFO_EXTENSION); 
		$extension = strtolower($image_path); 

		if($extension != "jpg" && $extension != "jpeg" && $extension != "png" && $extension != "gif" ) {
			$valid_file = false;
			$message	= "Maaf, file yang diijinkan hanya format JPG, JPEG, PNG & GIF. #".$extension;
		}



		
		if($valid_file == true)
		{
			
			$rename_nama_file	= date('YmdHis');
			$nama_file_baru		= $rename_nama_file.".".$extension;

			mysql_query("INSERT into film set judul='$judul',id_ketegori='$id_kategori',produksi='$produksi',tahun='$tahun',bioskop='$bioskop',jadwal='$jadwal',tiket='$tiket',gambar='$nama_file_baru'");
			move_uploaded_file($_FILES['gambar']['tmp_name'], '../../gambar/'.$nama_file_baru);
			header("location:index.php?page=film");
		}
	}
	
	else
	{
		
		echo "skdjksjdk";
	}
}
?>