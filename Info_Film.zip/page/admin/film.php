<?php
include"../../config.php";
$no = 1;
$qry_film = mysql_query("SELECT * from film");
?>
<div style="margin-top:30px;width:100%,height:50px;text-align:center;background:#0000ff;color:#fff;line-height:60px;font-size:20px;">
<b>Data Film</b>
</div>
<a href="index.php?page=input_film" class="btn btn-success" style="margin-top:20px;"><span class="glyphicon glyphicon-plus"> TAMBAH FILM</span></a>
<?php
@$aksi = $_GET['aksi'];
if($aksi=="input")
{
	include("input_film.php");
}
?>
<div class="th">
<table class="table table-bordered" style="margin-top:20px;">
 
	<th style=" background: #E6E6FA;"><center>No</center></th>
	<th style=" background: #E6E6FA;"><center>Judul</center></th>
	<th style=" background: #E6E6FA;"><center>Produksi</center></th>
	<th style=" background: #E6E6FA;"><center>Tahun</center></th>
	<th style=" background: #E6E6FA;"><center>Gambar</center></th>
	<th style=" background: #E6E6FA;"><center>Bioskop</center></th>
	<th style=" background: #E6E6FA;"><center>Jadwal</center></th>
	<th style=" background: #E6E6FA;"><center>Tiket</center></th>
	<th style=" background: #E6E6FA;"><center>aksi</center></th>
	<?php while($data = mysql_fetch_array($qry_film)) { ?>
	<tr>
	 <td><?php echo $no++ ?></td>
	 <td><?php echo $data['judul'] ?></td>
	 <td><?php echo $data['produksi'] ?></td>
	 <td><?php echo $data['tahun'] ?></td>
	 <td><center><img src="../../gambar/<?php echo $data['gambar'] ?>" style="width:100px;"></center></td>
	 <td><?php echo $data['bioskop'] ?></td>
	 <td><?php echo $data['jadwal']; ?></td>
	 <td><?php echo $data['tiket'] ?></td>
	 <td><a href="index.php?page=editfilm&id=<?php echo $data['id_film']; ?>"><center><span class="glyphicon glyphicon-pencil"></span></a> || <a href="hapus.php?id=<?php echo $data['id_film']; ?>"><span class="glyphicon glyphicon-trash"></span></center></a></td>
	</tr>
	<?php } ?>
</table>
</div>