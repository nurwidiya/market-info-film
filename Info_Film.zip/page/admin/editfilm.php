<link href="../../css/bootstrap.min.css" rel="stylesheet">
<?php
include"../../config.php";
$e=$_GET['id'];
$edit=mysql_query("SELECT * FROM film WHERE id_film='$e'");
$film = mysql_fetch_array($edit);
?>
<div style="margin-top:30px;width:100%,height:50px;text-align:center;background:#0000ff;color:#fff;line-height:60px;font-size:20px;margin-bottom:20px;">
Edit Film
</div>
<form action="e_film.php" method="post" enctype="multipart/form-data">
 		<input type="hidden" name="id_film" class="form-control" value =" <?php  echo $film['id_film'];?>">
 		<b>Kategori Film:</b><select name="kategori" class="form-control">
 			<?php
 			$d = mysql_query("SELECT * from kategori");
 			while($data = mysql_fetch_array($d)){ ?>;
 			<option> <?php echo $data['kategori']; ?> </option>
 			<?php } ?>
 		</select><br>
 		<b>Judul Film:</b> <input type="text" name="judul" class="form-control" value =" <?php  echo $film['judul'];?>" ><br>
 		<b>Produksi Film :</b><input type="text" name="produksi" class="form-control" value =" <?php  echo $film['produksi'];?>"><br>
 		<b>Tahun Film : </b><input type="text" name="tahun" class="form-control" value =" <?php  echo $film['tahun'];?>"><br>
 		<b>Gambar Film : </b><input type="file" name="gambar" class="form-control" value =" <?php  echo $film['gambar'];?>" ><br>
 		<b>Bioskop : </b><input type="text" name="bioskop" class="form-control" value =" <?php  echo $film['bioskop'];?>"><br>
 		<b>Jadwal Bioskop : </b><input type="text" name="jadwal" class="form-control" value =" <?php  echo $film['tiket'];?>" ><br>
 		<b>Tiket : </b><input type="text" name="tiket " class="form-control" value =" <?php  echo $film['tiket'];?>" ><br>
 		<td><input type="submit" class="btn btn-success" value="simpan">
</form>