<?php
$qry_kategori = mysql_query("SELECT * from kategori");

	?>
	<div style="margin-top:30px;width:100%,height:50px;text-align:center;background:#0000ff;color:#fff;line-height:60px;font-size:20px;">
Tambah Film
</div>
<form method="post" class="form-group" action="tambah_film.php" enctype="multipart/form-data" style="margin-top:20px;">
	<select name="kat" class="form-control">
	<?php 
	while($kategori=mysql_fetch_array($qry_kategori)){
	?>
			<option><?php echo $kategori['kategori']; ?></option>
			<?php } ?>
	</select><br>
	<input type="text" name="judul" placeholder="Judul Film" class="form-control"><br>
	<input type="text" name="produksi" placeholder="Produksi Film" class="form-control"><br>
	<input type="text" name="tahun" placeholder="Tahun Film" class="form-control"><br>
	<input type="file" name="gambar" placeholder="Gambar Film" class="form-control"><br>
	<input type="text" name="bioskop" placeholder="Bioskop" class="form-control"><br>
	<input type="text" name="jadwal" placeholder="Jadwal Bioskop" class="form-control"><br>
	<input type="text" name="tiket" placeholder="Tiket" class="form-control"><br>
	<input type="submit" name="simpan" value="simpan" class="btn btn-success"><br>
	</form>